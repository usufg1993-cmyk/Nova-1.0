package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusV: TextView
    private lateinit var toggle: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("nova", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(40), dp(18), dp(24))
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#05070D"))
            addView(col)
        }
        fun label(t: String, sz: Float, c: String = "#E8EEFC") = TextView(this).apply {
            text = t; textSize = sz; setTextColor(Color.parseColor(c)); setPadding(0, dp(6), 0, dp(6))
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
        }
        fun field(hint: String, value: String, secret: Boolean) = EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }

        col.addView(label("NOVA", 30f, "#5DE6FF"))
        col.addView(label("\"Hey Nova\" de, arka planda uyansın.", 15f, "#8B97B5"))
        val keyF = field("Gemini API anahtarı", p.getString("key", "") ?: "", true)
        val modelF = field("Model adı (boş bırakırsan gemini-flash-latest)", p.getString("model", "") ?: "", false)
        col.addView(label("Gemini ayarları", 16f))
        col.addView(keyF)
        col.addView(modelF)
        col.addView(btn("Ayarları kaydet") {
            p.edit().putString("key", keyF.text.toString().trim()).putString("model", modelF.text.toString().trim()).apply()
            Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show()
        })
        col.addView(label("İzinler", 16f))
        statusV = label("", 14f, "#8B97B5")
        col.addView(statusV)
        col.addView(btn("1) Mikrofon, bildirim ve rehber izni ver") {
            val perms = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_CONTACTS)
            else arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS)
            requestPermissions(perms, 1)
        })
        col.addView(btn("2) Diğer uygulamaların üzerinde göster izni") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("3) Pil kısıtlamasını kaldır") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        })
        toggle = btn("NOVA'yı başlat") {
            if (NovaService.running) {
                NovaService.userStop = true
                stopService(Intent(this, NovaService::class.java))
                Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 700)
            } else startNova()
        }
        val bootB = btn("") {}
        fun bootText() = "Telefon açılınca hatırlat: " + if (p.getBoolean("boot", false)) "Açık" else "Kapalı"
        bootB.text = bootText()
        bootB.setOnClickListener {
            p.edit().putBoolean("boot", !p.getBoolean("boot", false)).apply()
            bootB.text = bootText()
        }
        col.addView(bootB)
        col.addView(toggle)
        setContentView(sv)
        handleIntent(intent)
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        setIntent(i)
        handleIntent(i)
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.getBooleanExtra("autostart", false)) {
            i.removeExtra("autostart")
            startNova()
        }
    }

    private fun startNova() {
        if (NovaService.running) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Önce mikrofon izni ver", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, NovaService::class.java))
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 700)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val ov = Settings.canDrawOverlays(this)
        val bat = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        val ct = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        fun s(x: Boolean) = if (x) "Tamam" else "Eksik"
        statusV.text = "Mikrofon: ${s(mic)}\nRehber: ${s(ct)}\nÜstte gösterme: ${s(ov)}\nPil kısıtlaması kaldırıldı: ${s(bat)}"
        toggle.text = if (NovaService.running) "NOVA'yı durdur" else "NOVA'yı başlat"
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        refresh()
    }
}
