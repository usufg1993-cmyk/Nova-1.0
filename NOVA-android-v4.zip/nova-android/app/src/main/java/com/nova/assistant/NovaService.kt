package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ResolveInfo
import android.content.pm.ServiceInfo
import android.Manifest
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class NovaService : Service(), RecognitionListener {
    companion object {
        @Volatile var running = false
        @Volatile var userStop = false
        const val CH = "nova"
        val WAKE_WORDS = listOf("hey nova", "hay nova", "a nova", "hey no va", "hey novo", "hey nover")
        val WAKE_GRAMMAR: String = JSONArray(WAKE_WORDS + "[unk]").toString()
        const val SYS = "Sen NOVA adlı Türkçe sesli kişisel asistansın. Her zaman Türkçe, kısa, net ve konuşma diline uygun cevap ver. Markdown, liste işareti ve emoji kullanma. Eğitim, kodlama, Arduino ve elektronik konularında adım adım yardım et. Kullanıcı yazılımcı değil, sade anlat."
    }

    private val main = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)
    private var model: Model? = null
    private var wake: SpeechService? = null
    private var asr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private val history = ArrayList<Pair<String, String>>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        createChannel()
        val n = note("Hazırlanıyor…")
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Throwable) {
            // Android 14+: mikrofonlu servis arka plandan başlatılamaz (sistem yeniden başlatması dahil).
            running = false
            userStop = true
            alert("NOVA başlatılamadı", "Dokunup uygulamayı açarak NOVA'yı yeniden başlat.", true)
            stopSelf()
            return START_NOT_STICKY
        }
        userStop = false
        if (running) return START_STICKY
        running = true
        tts = TextToSpeech(this) { s ->
            if (s == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                ttsOk = true
            }
        }
        Thread { loadModel() }.start()
        return START_STICKY
    }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "NOVA", NotificationManager.IMPORTANCE_LOW))
    }

    private fun note(t: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH).setContentTitle("NOVA").setContentText(t)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build()
    }

    private fun alert(title: String, text: String, reopen: Boolean = false) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("nova_alert", "NOVA bildirimleri", NotificationManager.IMPORTANCE_HIGH))
            val i = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (reopen) i.putExtra("autostart", true)
            val pi = PendingIntent.getActivity(this, if (reopen) 2 else 3, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(if (reopen) 11 else 10, Notification.Builder(this, "nova_alert")
                .setContentTitle(title)
                .setContentText(text.take(100))
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build())
        } catch (_: Throwable) {}
    }

    private fun update(t: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, note(t))
    }

    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: emptyArray()
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (n in list) copyAssets("$path/$n", File(dest, n))
        }
    }

    private fun loadModel() {
        try {
            val dir = File(filesDir, "model")
            val ok = File(dir, ".ok")
            if (!ok.exists()) {
                dir.deleteRecursively()
                copyAssets("model-en-us", dir)
                ok.writeText("1")
            }
            model = Model(dir.absolutePath)
            startWake()
        } catch (e: Throwable) {
            update("Model yüklenemedi: ${e.message}")
            alert("NOVA modeli yüklenemedi", e.message ?: "Bilinmeyen hata")
        }
    }

    private fun startWake() {
        main.post {
            if (!running) return@post
            val m = model ?: return@post
            stopWake()
            try {
                val rec = Recognizer(m, 16000f, WAKE_GRAMMAR)
                val ss = SpeechService(rec, 16000f)
                ss.startListening(this)
                wake = ss
                update("\"Hey Nova\" diyerek çağır")
            } catch (e: Throwable) {
                update("Mikrofon başlatılamadı: ${e.message}")
                alert("NOVA mikrofonu açamadı", e.message ?: "Başka bir uygulama mikrofonu kullanıyor olabilir.", true)
            }
        }
    }

    private fun stopWake() {
        wake?.let { try { it.stop(); it.shutdown() } catch (_: Throwable) {} }
        wake = null
    }

    private fun check(h: String?) {
        if (h != null && WAKE_WORDS.any { h.contains(it) } && busy.compareAndSet(false, true)) {
            main.post { onWake() }
        }
    }

    override fun onPartialResult(hypothesis: String?) { check(hypothesis) }
    override fun onResult(hypothesis: String?) { check(hypothesis) }
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) {
        update("Dinleme hatası: ${exception?.message}")
        alert("NOVA dinleme hatası", exception?.message ?: "Bilinmeyen hata", true)
    }
    override fun onTimeout() {}

    private fun onWake() {
        stopWake()
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (_: Throwable) {}
        update("Dinliyorum…")
        main.postDelayed({ listenCommand() }, 400)
    }

    private fun listenCommand() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Bu cihazda konuşma tanıma yok.") { resume() }
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        asr = r
        r.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) { say("Seni duyamadım.") { resume() } }
            override fun onResults(res: Bundle?) {
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) say("Seni duyamadım.") { resume() } else handle(t)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        r.startListening(i)
    }

    private fun handle(text: String) {
        update("Düşünüyorum…")
        val s = text.lowercase(Locale("tr", "TR")).trim().trimEnd('.', '!', '?')
        if (handleTorch(s)) return
        if (handleAlarm(s)) return
        val callQ = parseCall(s)
        if (callQ != null) {
            val digits = callQ.replace(Regex("[\\s-]"), "")
            if (digits.matches(Regex("\\+?\\d{3,}"))) {
                dial(digits, digits); return
            }
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                say("Rehber izni vermen gerekiyor.") { resume() }; return
            }
            Thread {
                val r = findContact(callQ)
                main.post { if (r != null) dial(r.first, r.second) else fallback(text) }
            }.start()
            return
        }
        fallback(text)
    }

    private fun fallback(text: String) {
        val app = parseOpen(text)
        if (app != null) {
            val label = openApp(app)
            say(if (label != null) "$label açılıyor." else "$app adlı uygulamayı bulamadım.") { resume() }
        } else askGemini(text)
    }

    private fun handleTorch(s: String): Boolean {
        if (!(s.contains("fener") || s.contains("flaş") || s.contains("flash"))) return false
        val on = when {
            s.contains("kapa") || s.contains("söndür") -> false
            s.contains("aç") || s.contains("yak") -> true
            else -> return false
        }
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            if (id == null) say("Bu cihazda el feneri yok.") { resume() }
            else {
                cm.setTorchMode(id, on)
                say(if (on) "Fener açıldı." else "Fener kapatıldı.") { resume() }
            }
        } catch (e: Throwable) {
            say("Feneri kontrol edemedim.") { resume() }
        }
        return true
    }

    private fun humanDur(sec: Int): String {
        val h = sec / 3600; val m = (sec % 3600) / 60; val x = sec % 60
        return listOfNotNull(
            if (h > 0) "$h saat" else null,
            if (m > 0) "$m dakika" else null,
            if (x > 0) "$x saniye" else null
        ).joinToString(" ")
    }

    private fun handleAlarm(s: String): Boolean {
        val timerWord = s.contains("zamanlayıcı") || s.contains("sayaç")
        if (!timerWord && !s.contains("alarm")) return false
        if (!(s.contains("kur") || s.contains("ayarla") || s.contains("koy") || s.contains("başlat"))) return false
        try {
            val rel = Regex("(\\d+)\\s*(saat|dakika|dk|saniye|sn)").findAll(s).toList()
            if (rel.isNotEmpty()) {
                var sec = 0L
                for (m in rel) {
                    val n = m.groupValues[1].toLongOrNull() ?: return false
                    sec += when (m.groupValues[2]) { "saat" -> n * 3600; "dakika", "dk" -> n * 60; else -> n }
                }
                if (sec <= 0 || sec > 86400) { say("Süre geçersiz görünüyor.") { resume() }; return true }
                val si = sec.toInt()
                startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, si)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "NOVA")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                say("${humanDur(si)} için zamanlayıcı kuruldu.") { resume() }
                return true
            }
            if (timerWord) { say("Kaç dakika için kurayım?") { resume() }; return true }
            val t = Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(s)
            var h: Int
            val m: Int
            if (t != null) {
                h = t.groupValues[1].toInt(); m = t.groupValues[2].toInt()
            } else {
                val one = Regex("(\\d{1,2})").find(s)
                if (one == null) { say("Saat kaçta kurayım?") { resume() }; return true }
                h = one.groupValues[1].toInt(); m = if (s.contains("buçuk")) 30 else 0
            }
            if (h > 23 || m > 59) { say("Saat geçersiz görünüyor.") { resume() }; return true }
            if ((s.contains("akşam") || s.contains("öğleden sonra")) && h < 12) h += 12
            else if (s.contains("gece") && h in 8..11) h += 12
            startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "NOVA")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            say("Saat ${"%d:%02d".format(h, m)} için alarm kuruldu.") { resume() }
        } catch (e: Throwable) {
            say("Alarm kurulamadı.") { resume() }
        }
        return true
    }

    private fun parseCall(s: String): String? {
        val m = Regex("^(.+?)\\s+(ara|arar mısın|arasana|arayabilir misin|arayın|arayalım)$").find(s) ?: return null
        val n = m.groupValues[1].substringBefore('\'').substringBefore('’').trim()
        return if (n.isEmpty()) null else n
    }

    private fun score(l: String, nq: String) = when {
        l == nq -> 4
        l.startsWith(nq) -> 3
        l.contains(nq) -> 2
        l.length >= 3 && nq.contains(l) -> 1
        else -> 0
    }

    private fun findContact(q: String): Pair<String, String>? {
        val nq = norm(q)
        if (nq.isEmpty()) return null
        var best: Pair<String, String>? = null
        var bs = 0
        try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    val sc = score(norm(name), nq)
                    if (sc > bs) { bs = sc; best = name to num }
                }
            }
        } catch (_: Throwable) {}
        return best
    }

    private fun dial(label: String, number: String) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            say("$label aranıyor. Arama tuşuna bas.") { resume() }
        } catch (e: Throwable) {
            say("Arama ekranı açılamadı.") { resume() }
        }
    }

    private fun parseOpen(t: String): String? {
        val s = t.lowercase(Locale("tr", "TR")).trim().trimEnd('.', '!', '?')
        val m = Regex("^(.+?)\\s+(aç|açar mısın|açsana|açabilir misin|açın|başlat)$").find(s) ?: return null
        var n = m.groupValues[1].substringBefore('\'').substringBefore('’')
        for (suf in listOf(" uygulamasını", " uygulamasi", " uygulamayı", " uygulaması")) n = n.removeSuffix(suf)
        n = n.trim()
        return if (n.isEmpty()) null else n
    }

    private fun norm(s: String): String =
        s.lowercase(Locale("tr", "TR")).replace('ı', 'i').replace('ş', 's').replace('ç', 'c')
            .replace('ğ', 'g').replace('ö', 'o').replace('ü', 'u').filter { it.isLetterOrDigit() }

    private fun lev(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return dp[a.length][b.length]
    }

    private fun openApp(q: String): String? {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val nq = norm(q)
        if (nq.isEmpty()) return null
        var best: ResolveInfo? = null
        var bs = 0
        for (r in list) {
            val l = norm(r.loadLabel(pm).toString())
            val sc = when {
                l == nq -> 4
                l.startsWith(nq) -> 3
                l.contains(nq) -> 2
                l.length >= 3 && nq.contains(l) -> 1
                else -> 0
            }
            if (sc > bs) { bs = sc; best = r }
        }
        if (best == null) {
            var bd = 3
            for (r in list) {
                val d = lev(norm(r.loadLabel(pm).toString()), nq)
                if (d < bd) { bd = d; best = r }
            }
        }
        val r = best ?: return null
        val intent = pm.getLaunchIntentForPackage(r.activityInfo.packageName) ?: return null
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(intent); r.loadLabel(pm).toString() } catch (e: Exception) { null }
    }

    private fun askGemini(text: String) {
        val p = getSharedPreferences("nova", MODE_PRIVATE)
        val key = p.getString("key", "") ?: ""
        val mdl = (p.getString("model", "") ?: "").ifBlank { "gemini-flash-latest" }
        if (key.isBlank()) {
            say("Önce uygulamayı açıp Gemini anahtarını girmelisin.") { resume() }
            return
        }
        synchronized(history) { history.add("user" to text) }
        Thread {
            var out: String
            try {
                val contents = JSONArray()
                val recent = synchronized(history) { history.takeLast(12) }
                for ((r, t) in recent) {
                    contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t))))
                }
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
                    .put("contents", contents)
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$mdl:generateContent").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                if (code == 200) {
                    val j = JSONObject(c.inputStream.bufferedReader().readText())
                    out = j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                        .getJSONArray("parts").getJSONObject(0).getString("text").trim()
                    synchronized(history) { history.add("model" to out) }
                } else {
                    out = when (code) {
                        400, 403 -> "Gemini anahtarı hatalı görünüyor. Ayarları kontrol et."
                        404 -> "Model adı bulunamadı. Ayarlardaki model adını kontrol et."
                        429 -> "Ücretsiz kullanım sınırına ulaşıldı. Biraz sonra tekrar dene."
                        else -> "Gemini hatası, kod $code."
                    }
                    synchronized(history) { if (history.isNotEmpty()) history.removeAt(history.size - 1) }
                }
            } catch (e: Exception) {
                out = "İnternet bağlantısı kurulamadı."
                synchronized(history) { if (history.isNotEmpty() && history.last().first == "user") history.removeAt(history.size - 1) }
            }
            main.post { alert("NOVA", out); say(out) { resume() } }
        }.start()
    }

    private fun say(text: String, done: () -> Unit) {
        val t = tts
        if (t == null || !ttsOk) { done(); return }
        update("Konuşuyor…")
        val clean = text.replace(Regex("[*_`#>]"), "").take(3500)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { done() } }
            override fun onError(id: String?) { main.post { done() } }
        })
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nova")
    }

    private fun resume() {
        try { asr?.destroy() } catch (_: Throwable) {}
        asr = null
        busy.set(false)
        startWake()
    }

    override fun onDestroy() {
        if (!userStop) alert("NOVA durdu", "Dinleme kapandı. Yeniden başlatmak için dokun.", true)
        running = false
        stopWake()
        try { asr?.destroy() } catch (_: Throwable) {}
        tts?.shutdown()
        try { model?.close() } catch (_: Throwable) {}
        super.onDestroy()
    }
}
